import time
import random
import csv
from datetime import datetime

def generate_reading():
    return {
        "timestamp": datetime.utcnow().isoformat(),
        "temperature": round(random.uniform(20, 35), 2),
        "humidity": round(random.uniform(30, 70), 2),
        "light": round(random.uniform(100, 800), 0),
    }

def main():
    fieldnames = ["timestamp", "temperature", "humidity", "light"]
    with open("sensor_log.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        print("Writing sensor data to sensor_log.csv. Press Ctrl+C to stop.")
        try:
            while True:
                reading = generate_reading()
                writer.writerow(reading)
                f.flush()
                print(reading)
                time.sleep(2)
        except KeyboardInterrupt:
            print("Stopped.")

if __name__ == "__main__":
    main()