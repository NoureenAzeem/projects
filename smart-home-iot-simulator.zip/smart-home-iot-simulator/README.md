# Smart Home IoT Simulator

Generates synthetic sensor readings (temperature, humidity, light) and logs them to a CSV file.